import java.util.Scanner;

public class Main {
    private static Scanner ingreso = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;

        do {

            System.out.println("----MENU----");
            System.out.println("1. Ejercicio 1");
            System.out.println("2. Ejercicio 2");
            System.out.println("3. Ejercicio 3");
            System.out.println("0. Salir del programa");
            System.out.print("Seleccione una opcion: ");

            opcion = ingreso.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Has seleccionado el ejercicio 1:");
                    ej1();
                    break;
                case 2:
                    System.out.println("Has seleccionado el ejercicio 2:");
                    ej2();
                    break;
                case 3:
                    System.out.println("Has seleccionado el ejercicio 3:");
                    ej3();
                    break;
                case 4:
                    System.out.println("Has seleccionado el ejercicio 4:");
                    ej4();
                    break;
                case 5:
                    System.out.println("Has seleccionado el ejercicio 5:");
                    ej5();
                    break;
                case 6:
                    System.out.println("Has seleccionado el ejercicio 6:");
                    ej6();
                    break;
                case 7:
                    System.out.println("Has seleccionado el ejercicio 7:");
                    ej7();
                    break;
                case 8:
                    System.out.println("Has seleccionado el ejercicio 8:");
                    ej8();
                    break;
                case 0:
                    System.out.println("Saliendo del programa.");
                    break;
                default:
                    System.out.println("Opcion invalida. Por favor intente de nuevo");
            }
            System.out.println();
        } while (opcion != 0);

    }

    private static void ej1() {
        int numN = 56;
        double numA = 3.56;
        char numC = 'd';
        double sumaNyA = numN + numA;
        double difAyN = numA - numN;
        int valorC = numC;

        System.out.println("El numN es: " + numN + ",el numA: " + numA + " y el numC: " + numC);
        System.out.println("La suma de numN y numA es: " + sumaNyA);
        System.out.println("La diferencia de numA y numN es: " + difAyN);
        System.out.println("El valor numerico en tabla ascii de " + numC + ", es:" + valorC);
    }

    private static void ej2() {
        int numX = 68;
        int numY = 45;
        double numM = 64.6589;
        double numN = 15.689;

        System.out.println("El valor de numX es: " +numX);
        System.out.println("El valor de numY es: " +numY);
        System.out.println("El valor de numM es: " +numM);
        System.out.println("El valor de numN es: " +numN);

        double suma = numX + numY + numM + numN;
        double dif = numX  - numY - numM - numN;
        double prod = numX  * numY * numM * numN;

        System.out.println("La suma de los numeros X, Y, M y N es: " + suma);
        System.out.println("La diferencia de los numeros X, Y, M y N es: " + dif);
        System.out.println("El producto de los numeros X, Y, M y N es: " + prod);

    }

    private static void ej3() {
        System.out.println("Ingrese un valor entero: ");
        int N = ingreso.nextInt();
        int nIncre = N + 77;
        int a3 = nIncre - (nIncre -3);
        int doble = N * 2;

        System.out.println("Si le sumamos 77 el numero es: " + nIncre);
        System.out.println("Lo llevamos al valor pedido:" + a3);
        System.out.println("El doble seria: " + doble);
    }

    private static void ej4() {
        int A = 3;
        int B = 5;
        int C = 8;
        int D = 2;

        System.out.println("El valor original de A es: " + A);
        System.out.println("El valor original de B es: " + B);
        System.out.println("El valor original de C es: " + C);
        System.out.println("El valor original de D es: " + D);
        int aux;

        aux = B;
        B = C;
        C = A;
        A = D;
        D = aux;

        System.out.println("El valor final de A es: " + A);
        System.out.println("El valor final de B es: " + B);
        System.out.println("El valor final de C es: " + C);
        System.out.println("El valor final de D es: " + D);
    }

    private static void ej5() {
        int A = 4;

        if ( A %2 == 0){
            System.out.println("El numero A es par");
        } else {
            System.out.println("El numero A es impar");
        }
    }

    private static void ej6() {
        System.out.println("Ingrese un valor entero:");
        int B = ingreso.nextInt();

        if ( B >= 0){
            System.out.println("El numero B es positivo");
        } else {
            System.out.println("El numero B es negativo");
        }
    }

    private static void ej7() {
        ingreso.nextLine();
        String palabra;
        System.out.println("Ingrese una palabra");
        palabra = ingreso.nextLine();

        char caracter = palabra.charAt(0);
        int valorC = caracter;
        System.out.println("La primera letra de la palabra es: "+ caracter);
        System.out.println("El valor de la primera letra de la palabra es: "+ valorC);
    }

    private static void ej8() {
        ingreso.nextLine();
        int C = ingreso.nextInt();

        if ( C >= 0){
            System.out.println("El numero C es positivo");
        } else {
            System.out.println("El numero C es negativo");
        }
        if ( C %2 == 0){
            System.out.println("El numero C es par");
        } else {
            System.out.println("El numero C es impar");
        }
        if ( C %5 == 0){
            System.out.println("El numero C es multiplo de 5");
        } else {
            System.out.println("El numero C no es multiplo de 5");
        }
        if ( C %10 == 0){
            System.out.println("El numero C es multiplo de 10");
        } else {
            System.out.println("El numero C no es multiplo de 10");
        }
        if ( C >= 100){
            System.out.println("El numero C es mayor o igual a 100");
        } else {
            System.out.println("El numero C es menor a 100");
        }

    }
}
